if (enable_rgb && enable_depth){
  registration->apply(rgb, depth, &undistorted, &registered);
  std::cout << pcd_count << " " << registered.height << " " << registered.width << std::endl;
  std::ofstream myfile;
  char file_name[15];
  sprintf(file_name, "points%d.pcd",pcd_count++);
  myfile.open (file_name);
  myfile << "VERSION 0.7" << std::endl << "FIELDS x y z rgb"<< std::endl << "SIZE 4 4 4 4"
  << std::endl << "TYPE F F F U"<< std::endl << "COUNT 1 1 1 1"
  << std::endl << "WIDTH 512"<< std::endl << "HEIGHT 424"
  << std::endl << "VIEWPOINT 0 0 0 1 0 0 0"<< std::endl;
  myfile << "POINTS 217088" << std::endl << "DATA ascii"<< std::endl;
  for (size_t I = 0; I < registered.height; ++I){
      for (size_t J = 0; J < registered.width; ++J){
          float X, Y, Z, RGBVALUE;
          registration->getPointXYZRGB(&undistorted, &registered, I, J, X, Y, Z, RGBVALUE);
            myfile << X << " " << Y << " " << Z << " "<< RGBVALUE << std::endl;
      }
  }
  myfile.close();
  